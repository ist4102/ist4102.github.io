/*
 * Simple - 404 Page
 * Build Date: October 2016
 * Author: joashp
 */

"use strict"
particlesJS.load('particles-js', 'js/particles-404.json', function() {
});